
<?php
$hostname="localhost";
$hostuser="root";
$hostpass="";
$dbname="allo";
$dbconn= mysqli_connect($hostname,$hostuser,$hostpass,$dbname);
 ?>